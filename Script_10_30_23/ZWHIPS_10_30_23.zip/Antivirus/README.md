# Scripts related to antiviruses
All scripts log themselves to the console
## install_npe
Installs Norton Power Eraser. Useful program, but it does not seem like I can easily run it from the command line. I would have to use some clicking tool, and it may not be reliable.

## install_TDSSKiller
Installs TDSSKiller for rootkits

## install_sysinternals
Installs all of the sysinternals tools in the admin's Downloads folder.
Extracts them to C:\Users\administrator\Documents\Sysinternals

## setup_microsoft_defender
Sets up microsoft defender. This involves putting it back into its default configuration: no exclusions, turn realtime monitoring on, turn remediation suppression off.

## run_microsoft_defender
Runs a full scan of microsoft defender. Then removes the threats.