Scripts that are quick and non-blocking enough are put in script.ps1 to be run as a block

Scripts that are blocking / require manual intervention are put their respective subfolders